### Phase 2 Week 1 Quiz

* Create a flask app that serves a static HTML page or rendered template that looks like the screenshot. 

* Use html & css.
